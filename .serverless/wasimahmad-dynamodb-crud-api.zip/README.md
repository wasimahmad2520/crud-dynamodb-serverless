###  Serverless DynamoDB CRUD Operations
