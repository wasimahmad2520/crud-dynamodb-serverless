
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'wasimahmad',
  applicationName: 'wasimahmad-dynamodb-crud-api',
  appUid: 'jBtzZs0dBDgQBNv3Lr',
  orgUid: 'c8c6d1a9-9688-49e1-81d1-d72a711d155b',
  deploymentUid: 'a93d251c-5048-4fcd-9f2d-f1c59b43c10f',
  serviceName: 'wasimahmad-dynamodb-crud-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'wasimahmad-dynamodb-crud-api-dev-listPosts', timeout: 6 };

try {
  const userHandler = require('./post/list.js');
  module.exports.handler = serverlessSDK.handler(userHandler.listPosts, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}